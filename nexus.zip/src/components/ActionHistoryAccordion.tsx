import React, { useState } from 'react';
import {
  Sparkles,
  ChevronDown,
  Terminal,
  Lightbulb,
  FileText,
  Wrench,
  CheckSquare,
  RefreshCw,
  MessageSquare,
  FileCode,
  CheckCircle2,
  ChevronRight
} from 'lucide-react';
import { cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';
import { ActionStep, ActionStepKind } from '../types/secrets';

interface ActionHistoryAccordionProps {
  steps?: ActionStep[];
  modifiedFiles?: string[];
  isLoading?: boolean;
  modelName?: string;
  durationText?: string;
  defaultExpanded?: boolean;
}

// Icon mapper matching the Google AI Studio mobile build view screenshot exactly
const renderStepIcon = (kind: ActionStepKind) => {
  switch (kind) {
    case 'command':
      return <Terminal className="w-4 h-4 text-slate-400 stroke-[1.8] flex-shrink-0" />;
    case 'thought':
      return <Lightbulb className="w-4 h-4 text-slate-400 stroke-[1.8] flex-shrink-0" />;
    case 'read':
      return <FileText className="w-4 h-4 text-slate-400 stroke-[1.8] flex-shrink-0" />;
    case 'edit':
      return <FileCode className="w-4 h-4 text-slate-400 stroke-[1.8] flex-shrink-0" />;
    case 'build':
      return <Wrench className="w-4 h-4 text-slate-400 stroke-[1.8] flex-shrink-0" />;
    case 'qc':
      return <CheckSquare className="w-4 h-4 text-slate-400 stroke-[1.8] flex-shrink-0" />;
    case 'restart':
      return <RefreshCw className="w-4 h-4 text-slate-400 stroke-[1.8] flex-shrink-0" />;
    case 'respond':
      return <MessageSquare className="w-4 h-4 text-slate-400 stroke-[1.8] flex-shrink-0" />;
    default:
      return <Sparkles className="w-4 h-4 text-slate-400 stroke-[1.8] flex-shrink-0" />;
  }
};

// Default standard AI Studio steps if no custom steps provided
export const DEFAULT_STUDIO_STEPS: ActionStep[] = [
  { id: '1', kind: 'command', label: 'Ran command', timestamp: 1 },
  { id: '2', kind: 'thought', label: 'Thought for 4 seconds', timestamp: 2 },
  { id: '3', kind: 'command', label: 'Ran command', timestamp: 3 },
  { id: '4', kind: 'thought', label: 'Thought for 5 seconds', timestamp: 4 },
  { id: '5', kind: 'command', label: 'Ran command', timestamp: 5 },
  { id: '6', kind: 'read', label: 'Read file', timestamp: 6 },
  { id: '7', kind: 'command', label: 'Ran command', timestamp: 7 },
  { id: '8', kind: 'thought', label: 'Thought for 5 seconds', timestamp: 8 },
  { id: '9', kind: 'build', label: 'Built', timestamp: 9 },
  { id: '10', kind: 'qc', label: 'Ran quality control', timestamp: 10 },
  { id: '11', kind: 'restart', label: 'Restarted dev server', timestamp: 11 },
  { id: '12', kind: 'respond', label: 'Responded', timestamp: 12 },
];

export const ActionHistoryAccordion: React.FC<ActionHistoryAccordionProps> = ({
  steps = [],
  modifiedFiles = [],
  isLoading = false,
  modelName = 'Gemini 3.8 Flash',
  durationText,
  defaultExpanded = true,
}) => {
  const [isExpanded, setIsExpanded] = useState<boolean>(defaultExpanded);
  const [showFilesList, setShowFilesList] = useState<boolean>(false);

  // If steps array is empty, provide the realistic AI Studio build step sequence
  const displaySteps = steps.length > 0 ? steps : DEFAULT_STUDIO_STEPS;

  return (
    <div className="w-full space-y-2 select-none">
      {/* Subtitle / Model and Duration Header matching Google AI Studio screenshot */}
      <div className="text-xs text-slate-400 font-normal flex items-center gap-2 px-1">
        <span className="font-medium text-slate-300">{modelName}</span>
        <span>•</span>
        <span className="text-slate-400">
          {isLoading 
            ? `Running for ${durationText || '1s'}` 
            : `Ran for ${durationText || '5m 26s'}`}
        </span>
      </div>

      {/* Accordion Card Container matching Google AI Studio mobile build card */}
      <div className="bg-[#141519] border border-slate-800/90 rounded-2xl overflow-hidden shadow-lg transition-all">
        {/* Accordion Header Toggle */}
        <button
          type="button"
          onClick={() => setIsExpanded(!isExpanded)}
          className="w-full px-4 py-3 flex items-center justify-between text-left hover:bg-slate-800/30 transition-colors cursor-pointer group"
        >
          <div className="flex items-center gap-2.5">
            {/* Sparkle Icon with animated gradient/pulse when active */}
            <div className={cn(
              "w-4 h-4 flex items-center justify-center transition-transform",
              isLoading ? "animate-pulse text-sky-400" : "text-sky-400"
            )}>
              <Sparkles className="w-4 h-4 fill-sky-400 text-sky-400" />
            </div>
            <span className="text-sm font-semibold text-slate-200 tracking-tight">
              {isLoading ? 'Working' : 'Action history'}
            </span>
          </div>

          <div className="flex items-center gap-2">
            {isLoading && (
              <span className="flex h-2 w-2 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-sky-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-sky-500"></span>
              </span>
            )}
            <ChevronDown
              className={cn(
                "w-4 h-4 text-slate-400 group-hover:text-slate-200 transition-transform duration-200",
                isExpanded ? "rotate-180" : ""
              )}
            />
          </div>
        </button>

        {/* Accordion Content: Step-by-step activity list */}
        <AnimatePresence initial={false}>
          {isExpanded && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="px-4 pb-3 pt-1 space-y-2 border-t border-slate-800/40"
            >
              <div className="space-y-2.5 py-1">
                {displaySteps.map((step, idx) => {
                  const isLatestActive = isLoading && idx === displaySteps.length - 1;
                  return (
                    <div
                      key={step.id || idx}
                      className={cn(
                        "flex items-center gap-3 text-sm transition-colors",
                        isLatestActive 
                          ? "text-slate-100 font-medium" 
                          : "text-slate-300/90"
                      )}
                    >
                      {/* Step Icon */}
                      <div className="flex items-center justify-center w-5 h-5 flex-shrink-0">
                        {renderStepIcon(step.kind)}
                      </div>

                      {/* Step Label */}
                      <span className="text-[13.5px] leading-snug tracking-tight">
                        {step.label}
                      </span>

                      {/* Step Detail / Target file if available */}
                      {step.detail && (
                        <span className="text-[11px] font-mono text-slate-500 truncate max-w-[140px] sm:max-w-xs ml-1">
                          ({step.detail})
                        </span>
                      )}

                      {/* Right Pulse indicator if this step is actively executing */}
                      {isLatestActive && (
                        <span className="ml-auto w-1.5 h-1.5 rounded-full bg-sky-400 animate-pulse flex-shrink-0" />
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Completed Summary Checklist (Edited files & Built badge as shown in Screenshot 9) */}
              {!isLoading && modifiedFiles.length > 0 && (
                <div className="pt-2 border-t border-slate-800/50 space-y-2">
                  <button
                    type="button"
                    onClick={() => setShowFilesList(!showFilesList)}
                    className="flex items-center justify-between w-full text-xs font-semibold text-slate-300 hover:text-white py-1 cursor-pointer"
                  >
                    <div className="flex items-center gap-2">
                      <FileCode className="w-3.5 h-3.5 text-indigo-400" />
                      <span>Edited {modifiedFiles.length} files</span>
                    </div>
                    <ChevronRight className={cn("w-3.5 h-3.5 text-slate-500 transition-transform", showFilesList && "rotate-90")} />
                  </button>

                  {showFilesList && (
                    <div className="bg-[#0e0f12] rounded-xl p-2.5 border border-slate-800/80 space-y-1.5 max-h-36 overflow-y-auto">
                      {modifiedFiles.map((f, i) => (
                        <div key={i} className="flex items-center justify-between text-[11px] font-mono text-slate-300">
                          <span className="truncate pr-2">{f}</span>
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                        </div>
                      ))}
                    </div>
                  )}

                  <div className="flex items-center gap-2 text-xs text-slate-300 pt-0.5">
                    <Wrench className="w-3.5 h-3.5 text-slate-400" />
                    <span>Built</span>
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 ml-auto" />
                  </div>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};
