import React, { useState, useEffect } from 'react';
import { X, Flame, Check, AlertCircle, RefreshCw, Save, Shield } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface FirebaseModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const FirebaseModal: React.FC<FirebaseModalProps> = ({ isOpen, onClose }) => {
  const [apiKey, setApiKey] = useState('');
  const [projectId, setProjectId] = useState('');
  const [authDomain, setAuthDomain] = useState('');
  const [storageBucket, setStorageBucket] = useState('');
  const [messagingSenderId, setMessagingSenderId] = useState('');
  const [appId, setAppId] = useState('');
  const [rules, setRules] = useState('');
  const [status, setStatus] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<{ success?: boolean; message?: string } | null>(null);

  useEffect(() => {
    if (isOpen) {
      loadStatusAndRules();
    }
  }, [isOpen]);

  const loadStatusAndRules = async () => {
    try {
      const resStatus = await fetch('/api/firebase/status');
      const dataStatus = await resStatus.json();
      setStatus(dataStatus);
      if (dataStatus.config) {
        setApiKey(dataStatus.config.apiKey || '');
        setProjectId(dataStatus.config.projectId || '');
        setAuthDomain(dataStatus.config.authDomain || '');
        setStorageBucket(dataStatus.config.storageBucket || '');
        setMessagingSenderId(dataStatus.config.messagingSenderId || '');
        setAppId(dataStatus.config.appId || '');
      }

      const resRules = await fetch('/api/firebase/rules');
      const dataRules = await resRules.json();
      if (dataRules.rules) {
        setRules(dataRules.rules);
      }
    } catch {}
  };

  const handleSaveSetup = async () => {
    if (!apiKey || !projectId) {
      setResult({ success: false, message: 'API Key ও Project ID আবশ্যক' });
      return;
    }
    setIsLoading(true);
    setResult(null);
    try {
      const res = await fetch('/api/firebase/setup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          apiKey,
          projectId,
          authDomain,
          storageBucket,
          messagingSenderId,
          appId,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setResult({ success: true, message: 'Firebase সফলভাবে কনফিগার হয়েছে!' });
        loadStatusAndRules();
      } else {
        setResult({ success: false, message: data.error || 'কনফিগারেশন ব্যর্থ হয়েছে' });
      }
    } catch (err: any) {
      setResult({ success: false, message: err.message || 'এরর ঘটেছে' });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm"
          />

          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 15 }}
            className="relative w-full max-w-lg bg-[#0c1017] border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] z-10"
          >
            {/* Header */}
            <div className="px-6 py-4 border-b border-slate-800/80 flex items-center justify-between bg-slate-900/50">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-amber-500/10 border border-amber-500/20 rounded-xl text-amber-400">
                  <Flame className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Firebase ইন্টিগ্রেশন</h3>
                  <p className="text-xs text-slate-400">ডাটাবেজ ও ক্লাউড অথেন্টিকেশন কনফিগার করুন</p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Body */}
            <div className="p-6 space-y-3.5 overflow-y-auto text-xs">
              {status?.configured && (
                <div className="p-3 bg-emerald-950/30 border border-emerald-500/30 rounded-xl text-emerald-300 flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                  <span>Firebase সক্রিয় রয়েছে (Project: <strong>{status.config?.projectId}</strong>)</span>
                </div>
              )}

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Firebase API Key *</label>
                <input
                  type="password"
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                  placeholder="AIzaSy..."
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-white font-mono placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Project ID *</label>
                <input
                  type="text"
                  value={projectId}
                  onChange={(e) => setProjectId(e.target.value)}
                  placeholder="my-project-12345"
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Auth Domain (Optional)</label>
                  <input
                    type="text"
                    value={authDomain}
                    onChange={(e) => setAuthDomain(e.target.value)}
                    placeholder="project.firebaseapp.com"
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">App ID (Optional)</label>
                  <input
                    type="text"
                    value={appId}
                    onChange={(e) => setAppId(e.target.value)}
                    placeholder="1:12345:web:abcd"
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              {rules && (
                <div>
                  <label className="block text-slate-300 font-semibold mb-1 flex items-center gap-1.5">
                    <Shield className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Firestore Security Rules</span>
                  </label>
                  <pre className="p-3 bg-slate-950 border border-slate-800 rounded-xl text-slate-400 font-mono text-[11px] max-h-24 overflow-y-auto">
                    {rules}
                  </pre>
                </div>
              )}

              {result && (
                <div
                  className={`p-3 rounded-xl border flex items-center gap-2 ${
                    result.success
                      ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
                      : 'bg-rose-950/40 border-rose-500/40 text-rose-300'
                  }`}
                >
                  {result.success ? <Check className="w-4 h-4 text-emerald-400" /> : <AlertCircle className="w-4 h-4 text-rose-400" />}
                  <span>{result.message}</span>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="px-6 py-4 border-t border-slate-800/80 bg-slate-900/40 flex items-center justify-between">
              <button
                onClick={onClose}
                className="px-4 py-1.5 text-slate-400 hover:text-white rounded-xl transition-all cursor-pointer"
              >
                বাতিল
              </button>
              <button
                onClick={handleSaveSetup}
                disabled={isLoading}
                className="flex items-center gap-2 px-5 py-2 bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white font-semibold rounded-xl transition-all cursor-pointer shadow-lg shadow-amber-600/30"
              >
                {isLoading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-4 h-4" />}
                <span>সেভ ও কনফিগার</span>
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
