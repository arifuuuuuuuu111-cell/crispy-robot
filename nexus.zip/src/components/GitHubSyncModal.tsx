import React, { useState, useEffect } from 'react';
import { X, Github, Check, AlertCircle, RefreshCw, ExternalLink, Lock, Globe } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface GitHubSyncModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const GitHubSyncModal: React.FC<GitHubSyncModalProps> = ({ isOpen, onClose }) => {
  const [token, setToken] = useState(() => localStorage.getItem('nexus_github_token') || '');
  const [repoName, setRepoName] = useState('nexus-generated-app');
  const [isPrivate, setIsPrivate] = useState(false);
  const [commitMessage, setCommitMessage] = useState('Sync project from Nexus AI');
  const [status, setStatus] = useState<any>(null);
  const [isVerifying, setIsVerifying] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [result, setResult] = useState<{ success?: boolean; message?: string; url?: string } | null>(null);

  useEffect(() => {
    if (isOpen) {
      checkStatus();
    }
  }, [isOpen]);

  const checkStatus = async () => {
    try {
      const res = await fetch('/api/github/status');
      const data = await res.json();
      setStatus(data);
    } catch {}
  };

  const handleVerify = async () => {
    if (!token) return;
    setIsVerifying(true);
    setResult(null);
    try {
      const res = await fetch('/api/github/verify-token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token }),
      });
      const data = await res.json();
      if (data.valid) {
        localStorage.setItem('nexus_github_token', token);
        setStatus({ configured: true, user: data.user });
        setResult({ success: true, message: `সংযুক্ত সফল হয়েছে: @${data.user?.login}` });
      } else {
        setResult({ success: false, message: data.error || 'ভেরিফিকেশন ব্যর্থ হয়েছে' });
      }
    } catch (err: any) {
      setResult({ success: false, message: err.message || 'ভেরিফিকেশন এরর' });
    } finally {
      setIsVerifying(false);
    }
  };

  const handleSync = async () => {
    setIsSyncing(true);
    setResult(null);
    try {
      const res = await fetch('/api/github/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token,
          repoName,
          isPrivate,
          commitMessage,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setResult({
          success: true,
          message: 'সফলভাবে GitHub এ পুশ হয়েছে!',
          url: data.repoUrl,
        });
      } else {
        setResult({ success: false, message: data.error || 'সিঙ্ক ব্যর্থ হয়েছে' });
      }
    } catch (err: any) {
      setResult({ success: false, message: err.message || 'সিঙ্ক এরর' });
    } finally {
      setIsSyncing(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm"
          />

          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 15 }}
            className="relative w-full max-w-lg bg-[#0c1017] border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col z-10"
          >
            {/* Header */}
            <div className="px-6 py-4 border-b border-slate-800/80 flex items-center justify-between bg-slate-900/50">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-slate-800 border border-slate-700/80 rounded-xl text-white">
                  <Github className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">GitHub সিঙ্ক (GitHub Sync)</h3>
                  <p className="text-xs text-slate-400">আপনার প্রজেক্টের কোড GitHub রিপোজিটরিতে পুশ করুন</p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Body */}
            <div className="p-6 space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  GitHub Personal Access Token (repo scope)
                </label>
                <div className="flex gap-2">
                  <input
                    type="password"
                    value={token}
                    onChange={(e) => setToken(e.target.value)}
                    placeholder="ghp_xxxxxxxxxxxxxxxxxxxx"
                    className="flex-1 px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-white font-mono placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                  />
                  <button
                    onClick={handleVerify}
                    disabled={isVerifying || !token}
                    className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-semibold rounded-xl transition-all flex items-center gap-1.5 cursor-pointer"
                  >
                    {isVerifying ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : 'ভেরিফাই'}
                  </button>
                </div>
              </div>

              {status?.user && (
                <div className="p-3 bg-emerald-950/30 border border-emerald-500/30 rounded-xl text-emerald-300 flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-400" />
                  <span>কানেক্টেড ইউজার: <strong>@{status.user.login}</strong></span>
                </div>
              )}

              <div>
                <label className="block text-slate-300 font-semibold mb-1">রিপোজিটরির নাম (Repo Name)</label>
                <input
                  type="text"
                  value={repoName}
                  onChange={(e) => setRepoName(e.target.value)}
                  placeholder="nexus-generated-app"
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => setIsPrivate(false)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border transition-all ${
                    !isPrivate ? 'bg-indigo-600/20 border-indigo-500 text-indigo-300' : 'bg-slate-900 border-slate-800 text-slate-400'
                  }`}
                >
                  <Globe className="w-3.5 h-3.5" />
                  পাবলিক (Public)
                </button>
                <button
                  type="button"
                  onClick={() => setIsPrivate(true)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border transition-all ${
                    isPrivate ? 'bg-indigo-600/20 border-indigo-500 text-indigo-300' : 'bg-slate-900 border-slate-800 text-slate-400'
                  }`}
                >
                  <Lock className="w-3.5 h-3.5" />
                  প্রাইভেট (Private)
                </button>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">কমিট মেসেজ (Commit Message)</label>
                <input
                  type="text"
                  value={commitMessage}
                  onChange={(e) => setCommitMessage(e.target.value)}
                  placeholder="Sync project from Nexus AI"
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                />
              </div>

              {result && (
                <div
                  className={`p-3 rounded-xl border flex flex-col gap-1.5 ${
                    result.success
                      ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
                      : 'bg-rose-950/40 border-rose-500/40 text-rose-300'
                  }`}
                >
                  <div className="flex items-center gap-2 font-medium">
                    {result.success ? <Check className="w-4 h-4 text-emerald-400" /> : <AlertCircle className="w-4 h-4 text-rose-400" />}
                    <span>{result.message}</span>
                  </div>
                  {result.url && (
                    <a
                      href={result.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs text-sky-400 hover:underline flex items-center gap-1 mt-1 font-mono"
                    >
                      <ExternalLink className="w-3 h-3" />
                      {result.url}
                    </a>
                  )}
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="px-6 py-4 border-t border-slate-800/80 bg-slate-900/40 flex items-center justify-between">
              <button
                onClick={onClose}
                className="px-4 py-1.5 text-slate-400 hover:text-white rounded-xl transition-all cursor-pointer"
              >
                বাতিল
              </button>
              <button
                onClick={handleSync}
                disabled={isSyncing || !token}
                className="flex items-center gap-2 px-5 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-semibold rounded-xl transition-all cursor-pointer shadow-lg shadow-indigo-600/30"
              >
                {isSyncing ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>পুশ হচ্ছে...</span>
                  </>
                ) : (
                  <>
                    <Github className="w-4 h-4" />
                    <span>রিপোতে পুশ করুন</span>
                  </>
                )}
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
