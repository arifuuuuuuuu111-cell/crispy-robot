import React, { useState, useEffect } from 'react';
import { WifiOff } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const OfflineIndicator: React.FC = () => {
  const [isOnline, setIsOnline] = useState(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  return (
    <AnimatePresence>
      {!isOnline && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 20 }}
          className="fixed bottom-4 left-4 z-50 flex items-center gap-2 px-3.5 py-2 bg-amber-950/90 border border-amber-500/40 text-amber-200 text-xs rounded-xl shadow-xl backdrop-blur-md"
        >
          <WifiOff className="w-4 h-4 text-amber-400 animate-pulse" />
          <span>অফলাইন মোড — আগের চ্যাট এবং ফাইলগুলি ক্যাশে উপলব্ধ</span>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
