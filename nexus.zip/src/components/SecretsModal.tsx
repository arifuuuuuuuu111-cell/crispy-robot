import React, { useState, useEffect } from 'react';
import { X, Key, Plus, Trash2, Check, AlertCircle, RefreshCw, Eye, EyeOff, ShieldCheck, Zap, Sparkles, Layers, Cpu } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { getLocalKeys, saveLocalKeys, testKeyRemote } from '../lib/secretsManager';
import { ApiKeyItem, ProviderType } from '../types/secrets';

interface SecretsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onKeysUpdated?: () => void;
}

export interface ModelOption {
  id: string;
  name: string;
  badge?: string;
  description?: string;
}

// Model catalog directly synchronized with Nexus AI backend (apiOrchestrator.ts)
export const PROVIDER_MODELS: Record<string, ModelOption[]> = {
  gemini: [
    { id: 'gemini-3.5-flash-lite', name: 'Gemini 3.5 Flash Lite', badge: 'Fastest / Official', description: 'গুগলের নতুন আল্ট্রা-ফাস্ট মডেল (AQ. ও AIza কী-এর জন্য রিকমেন্ডেড)' },
    { id: 'gemini-3.8-flash', name: 'Gemini 3.8 Flash', badge: 'Flagship', description: 'গুগল এআই স্টুডিওর লেটেস্ট ফ্ল্যাগশিপ মডেল' },
    { id: 'gemini-3.1-flash-lite', name: 'Gemini 3.1 Flash Lite', badge: 'High Quota', description: 'হাই স্পিড, ১,৫০০ রিকোয়েস্ট/দিন ফ্রি লিমিট' },
    { id: 'gemini-4-argon', name: 'Gemini 4 Argon', badge: 'Experimental', description: 'নেক্সাস পরীক্ষামূলক আর্গন ইঞ্জিন' },
    { id: 'gemini-4-carbon', name: 'Gemini 4 Carbon', badge: 'Experimental', description: 'নেক্সাস পরীক্ষামূলক কার্বন ইঞ্জিন' },
    { id: 'gemini-3.1-flash-lite-image', name: 'Gemini 3.1 Flash Lite Image', badge: 'Image/Vision', description: 'ছবি বিশ্লেষণ ও ভিজ্যুয়াল জেনারেশন' },
    { id: 'gemini-nano-banana-2.1', name: 'Gemini Nano Banana 2.1', badge: 'Low Latency', description: 'আল্ট্রা লো-লেটেন্সি মডেল' },
    { id: 'gemini-3-pro-image', name: 'Gemini 3 Pro Image', badge: 'Image Pro', description: 'হাই-ফিডেলিটি ভিজ্যুয়াল ও আর্ট ডিজাইন' }
  ],
  openrouter: [
    { id: 'openrouter/free', name: 'OpenRouter Free (Auto Router)', badge: 'Free Default', description: 'ওপেনরাউটারের সেরা ফ্রি মডেল অটো-সিলেক্ট করে' },
    { id: 'deepseek/deepseek-r1:free', name: 'DeepSeek R1 (Free)', badge: 'Reasoning Free', description: 'অ্যাডভান্সড রিজনিং ও কোডিং' },
    { id: 'meta-llama/llama-3.3-70b-instruct:free', name: 'Llama 3.3 70B Instruct (Free)', badge: 'Free', description: 'মেটা লামা ৩.৩ ৭০বি ওপেন সোর্স' },
    { id: 'qwen/qwen-2.5-coder-32b-instruct:free', name: 'Qwen 2.5 Coder 32B (Free)', badge: 'Coder Free', description: 'কোডিং স্পেশালাইজড মডেল' },
    { id: 'mistralai/mistral-7b-instruct:free', name: 'Mistral 7B Instruct (Free)', badge: 'Free', description: 'দ্রুত ও নির্ভরযোগ্য মডেল' },
    { id: 'google/gemma-4-26b-a4b-it:free', name: 'Google Gemma 4 (Free)', badge: 'Google Free', description: 'গুগল গেমা ৪ ফ্রি মডেল' },
    { id: 'anthropic/claude-3.5-sonnet', name: 'Claude 3.5 Sonnet', badge: 'Top Coder', description: 'প্রিমিয়াম কোডিং ও প্রজেক্ট আর্কিটেকচার' },
    { id: 'openai/gpt-4o', name: 'OpenAI GPT-4o', badge: 'Multimodal', description: 'ওপেনএআই ফ্ল্যাগশিপ মাল্টিমোডাল মডেল' }
  ],
  grok: [
    { id: 'grok-2-latest', name: 'Grok 2 Latest', badge: 'Default', description: 'xAI গ্রক ২ লেটেস্ট মডেল' },
    { id: 'grok-beta', name: 'Grok Beta', badge: 'Beta', description: 'xAI গ্রক বিটা' },
    { id: 'grok-vision-beta', name: 'Grok Vision Beta', badge: 'Vision', description: 'ইমেজ ও ভিশন ক্যাপাবিলিটি' }
  ]
};

interface DetectedKey {
  provider: ProviderType;
  apiKey: string;
  name: string;
  model: string;
}

export function extractKeysFromText(rawText: string): DetectedKey[] {
  const results: DetectedKey[] = [];
  if (!rawText) return results;

  // 1. Google Gemini new format (starts with AQ.)
  const aqMatches = rawText.matchAll(/AQ\.[A-Za-z0-9_-]{50,55}/g);
  for (const m of aqMatches) {
    results.push({
      provider: 'gemini',
      apiKey: m[0],
      name: 'Gemini Key (AQ.)',
      model: 'gemini-3.5-flash-lite',
    });
  }

  // 2. Google Gemini legacy format (starts with AIzaSy)
  const aizaMatches = rawText.matchAll(/AIzaSy[A-Za-z0-9_-]{33}/g);
  for (const m of aizaMatches) {
    results.push({
      provider: 'gemini',
      apiKey: m[0],
      name: 'Gemini Key (AIzaSy)',
      model: 'gemini-3.1-flash-lite',
    });
  }

  // 3. OpenRouter format (starts with sk-or-v1-)
  const openRouterMatches = rawText.matchAll(/sk-or-v1-[a-f0-9]{64}/g);
  for (const m of openRouterMatches) {
    results.push({
      provider: 'openrouter',
      apiKey: m[0],
      name: 'OpenRouter Key',
      model: 'openrouter/free',
    });
  }

  // 4. xAI Grok format (starts with xai-)
  const grokMatches = rawText.matchAll(/xai-[A-Za-z0-9_-]+/g);
  for (const m of grokMatches) {
    results.push({
      provider: 'grok',
      apiKey: m[0],
      name: 'Grok Key',
      model: 'grok-2-latest',
    });
  }

  // Deduplicate by apiKey
  const seen = new Set<string>();
  return results.filter(k => {
    if (seen.has(k.apiKey)) return false;
    seen.add(k.apiKey);
    return true;
  });
}

export const SecretsModal: React.FC<SecretsModalProps> = ({
  isOpen,
  onClose,
  onKeysUpdated,
}) => {
  const [keys, setKeys] = useState<ApiKeyItem[]>([]);
  const [provider, setProvider] = useState<ProviderType>('gemini');
  const [keyName, setKeyName] = useState('');
  const [apiKey, setApiKey] = useState('');
  const [selectedModel, setSelectedModel] = useState<string>('gemini-3.5-flash-lite');
  const [customModel, setCustomModel] = useState<string>('');
  const [isCustomModelMode, setIsCustomModelMode] = useState<boolean>(false);
  const [isTesting, setIsTesting] = useState<string | null>(null);
  const [testResults, setTestResults] = useState<Record<string, { success: boolean; message?: string; latencyMs?: number }>>({});
  const [showKeys, setShowKeys] = useState<Record<string, boolean>>({});
  const [detectedBatchKeys, setDetectedBatchKeys] = useState<DetectedKey[]>([]);

  useEffect(() => {
    if (isOpen) {
      const current = getLocalKeys();
      setKeys(current);
    }
  }, [isOpen]);

  const handleProviderChange = (p: ProviderType) => {
    setProvider(p);
    setIsCustomModelMode(false);
    const available = PROVIDER_MODELS[p] || [];
    if (available.length > 0) {
      setSelectedModel(available[0].id);
    }
  };

  const handleApiKeyChange = (val: string) => {
    setApiKey(val);
    const trimmed = val.trim();

    // Check if multiple keys were pasted together
    const detected = extractKeysFromText(trimmed);
    if (detected.length > 1) {
      setDetectedBatchKeys(detected);
    } else {
      setDetectedBatchKeys([]);
    }
  };

  const handleModelSelectChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const val = e.target.value;
    if (val === '__custom__') {
      setIsCustomModelMode(true);
      setCustomModel('');
    } else {
      setIsCustomModelMode(false);
      setSelectedModel(val);
    }
  };

  const handleAddBatchKeys = () => {
    if (detectedBatchKeys.length === 0) return;
    const newItems: ApiKeyItem[] = detectedBatchKeys.map((dk, idx) => ({
      id: `key_${Date.now()}_${idx}`,
      name: dk.name,
      provider: dk.provider,
      apiKey: dk.apiKey,
      model: dk.model,
      isActive: true,
      rpmLimit: 60,
      status: 'healthy',
    }));

    const updated = [...keys, ...newItems];
    setKeys(updated);
    saveLocalKeys(updated);
    onKeysUpdated?.();

    setApiKey('');
    setKeyName('');
    setCustomModel('');
    setDetectedBatchKeys([]);
  };

  const handleAddKey = () => {
    if (!apiKey.trim()) return;

    // Always respect user's selected provider and accept ANY key format!
    const finalProvider = provider;
    const singleKey = apiKey.trim();
    const finalModel = isCustomModelMode && customModel.trim() 
      ? customModel.trim() 
      : selectedModel || (PROVIDER_MODELS[finalProvider]?.[0]?.id || (finalProvider === 'openrouter' ? 'openrouter/free' : 'gemini-3.1-flash-lite'));

    const newKey: ApiKeyItem = {
      id: `key_${Date.now()}`,
      name: keyName.trim() || `${finalProvider.toUpperCase()} Key`,
      provider: finalProvider,
      apiKey: singleKey,
      model: finalModel,
      isActive: true,
      rpmLimit: 60,
      status: 'healthy',
    };

    const updated = [...keys, newKey];
    setKeys(updated);
    saveLocalKeys(updated);
    onKeysUpdated?.();

    // Reset inputs
    setApiKey('');
    setKeyName('');
    setCustomModel('');
    setIsCustomModelMode(false);
    setDetectedBatchKeys([]);
  };

  const handleToggleKey = (id: string) => {
    const updated = keys.map(k => k.id === id ? { ...k, isActive: !k.isActive } : k);
    setKeys(updated);
    saveLocalKeys(updated);
    onKeysUpdated?.();
  };

  const handleUpdateKeyModel = (id: string, newModel: string) => {
    const updated = keys.map(k => k.id === id ? { ...k, model: newModel } : k);
    setKeys(updated);
    saveLocalKeys(updated);
    onKeysUpdated?.();
  };

  const handleDeleteKey = (id: string) => {
    const updated = keys.filter(k => k.id !== id);
    setKeys(updated);
    saveLocalKeys(updated);
    onKeysUpdated?.();
  };

  const handleTestKey = async (item: ApiKeyItem) => {
    setIsTesting(item.id);
    try {
      const res = await testKeyRemote(item.provider, item.apiKey, item.model);
      setTestResults(prev => ({
        ...prev,
        [item.id]: {
          success: res.success,
          message: res.message,
          latencyMs: res.latencyMs,
        }
      }));
    } catch (err: any) {
      setTestResults(prev => ({
        ...prev,
        [item.id]: {
          success: false,
          message: err.message || 'কানেকশন টেস্ট ব্যর্থ',
          latencyMs: 0,
        }
      }));
    } finally {
      setIsTesting(null);
    }
  };

  const currentModels = PROVIDER_MODELS[provider] || [];

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm"
          />

          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 15 }}
            className="relative w-full max-w-2xl bg-[#0c1017] border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] z-10"
          >
            {/* Header */}
            <div className="px-6 py-4 border-b border-slate-800/80 flex items-center justify-between bg-slate-900/50">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-indigo-500/10 border border-indigo-500/20 rounded-xl text-indigo-400">
                  <Key className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">API Keys & Model Manager</h3>
                  <p className="text-xs text-slate-400">Gemini (AQ.), OpenRouter ও Grok মডেল নির্বাচন</p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content */}
            <div className="p-6 overflow-y-auto space-y-5 text-xs">
              {/* Notice Banner */}
              <div className="p-3 bg-sky-950/40 border border-sky-500/30 rounded-xl text-sky-200 text-[11px] leading-relaxed flex items-start gap-2.5">
                <Sparkles className="w-4 h-4 text-sky-400 flex-shrink-0 mt-0.5" />
                <div>
                  <strong className="text-white">API Key ও মডেল নির্দেশিকা:</strong>
                  <ul className="list-disc pl-4 mt-1 space-y-0.5 text-slate-300">
                    <li><strong>Google Gemini:</strong> <code className="bg-sky-900/60 px-1 py-0.5 rounded text-sky-300 font-mono">AQ.</code> (নতুন AI Studio Auth Key) এবং <code className="bg-sky-900/60 px-1 py-0.5 rounded text-sky-300 font-mono">AIzaSy...</code> উভয় ফরম্যাটই সম্পূর্ণভাবে সমর্থিত ও কার্যকর।</li>
                    <li><strong>OpenRouter:</strong> যেকোনো OpenRouter কী ড্রপডাউন থেকে <code className="bg-sky-900/60 px-1 py-0.5 rounded text-sky-300 font-mono">openrouter/free</code> বা অন্য যেকোনো মডেল দিয়ে ব্যবহার করা যাবে।</li>
                    <li><strong>যেকোনো ফরম্যাট গ্রহণযোগ্য:</strong> সাইটে যেকোনো ফরম্যাটের কী সেভ, আপলোড এবং রিকোয়েস্ট পাঠানো যাবে।</li>
                  </ul>
                </div>
              </div>

              {/* Add New Key Form */}
              <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-2xl space-y-3.5">
                <div className="font-bold text-slate-200 flex items-center gap-2">
                  <Plus className="w-4 h-4 text-indigo-400" />
                  <span>নতুন API Key ও মডেল নির্বাচন</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  {/* Provider Selection */}
                  <div>
                    <label className="block text-slate-400 text-[11px] mb-1 font-medium">প্রোভাইডার</label>
                    <select
                      value={provider}
                      onChange={(e) => handleProviderChange(e.target.value as ProviderType)}
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none focus:border-indigo-500 cursor-pointer text-xs"
                    >
                      <option value="gemini">Google Gemini (AQ. / AIza...)</option>
                      <option value="openrouter">OpenRouter (sk-or-v1-...)</option>
                      <option value="grok">xAI Grok (xai-...)</option>
                    </select>
                  </div>

                  {/* Model Dropdown from Nexus-final repository */}
                  <div className="sm:col-span-2">
                    <label className="block text-slate-400 text-[11px] mb-1 font-medium flex items-center justify-between">
                      <span className="flex items-center gap-1.5">
                        <Cpu className="w-3.5 h-3.5 text-indigo-400" />
                        <span>মডেল নির্বাচন করুন (Nexus Catalog)</span>
                      </span>
                      {currentModels.find(m => m.id === selectedModel)?.badge && !isCustomModelMode && (
                        <span className="px-1.5 py-0.5 text-[9px] font-bold rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                          {currentModels.find(m => m.id === selectedModel)?.badge}
                        </span>
                      )}
                    </label>

                    {!isCustomModelMode ? (
                      <select
                        value={selectedModel}
                        onChange={handleModelSelectChange}
                        className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none focus:border-indigo-500 font-mono text-xs cursor-pointer"
                      >
                        {currentModels.map(m => (
                          <option key={m.id} value={m.id}>
                            {m.name} ({m.id})
                          </option>
                        ))}
                        <option value="__custom__">➕ কাস্টম মডেল লিখুন...</option>
                      </select>
                    ) : (
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={customModel}
                          onChange={(e) => setCustomModel(e.target.value)}
                          placeholder="মডেলের নাম লিখুন (যেমন: gemini-3.1-flash-lite)"
                          className="flex-1 px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white font-mono text-xs focus:outline-none focus:border-indigo-500"
                        />
                        <button
                          type="button"
                          onClick={() => setIsCustomModelMode(false)}
                          className="px-2.5 py-1 text-[11px] bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl transition-all cursor-pointer"
                        >
                          তালিকা
                        </button>
                      </div>
                    )}

                    {/* Model description snippet */}
                    {!isCustomModelMode && (
                      <div className="mt-1 text-[10px] text-slate-400">
                        {currentModels.find(m => m.id === selectedModel)?.description}
                      </div>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  <div className="sm:col-span-1">
                    <label className="block text-slate-400 text-[11px] mb-1 font-medium">কী এর নাম (ঐচ্ছিক)</label>
                    <input
                      type="text"
                      value={keyName}
                      onChange={(e) => setKeyName(e.target.value)}
                      placeholder="My Nexus Key"
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none focus:border-indigo-500 text-xs"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-slate-400 text-[11px] mb-1 font-medium">API Key *</label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={apiKey}
                        onChange={(e) => handleApiKeyChange(e.target.value)}
                        placeholder="AQ.Ab... অথবা sk-or-v1-..."
                        className="flex-1 px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white font-mono focus:outline-none focus:border-indigo-500 text-xs"
                      />
                      <button
                        onClick={handleAddKey}
                        disabled={!apiKey.trim()}
                        className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-bold rounded-xl transition-all flex items-center gap-1.5 cursor-pointer flex-shrink-0 shadow-lg shadow-indigo-600/30 text-xs"
                      >
                        <Plus className="w-4 h-4" />
                        <span>যুক্ত করুন</span>
                      </button>
                    </div>
                  </div>
                </div>

                {/* Batch detection banner */}
                {detectedBatchKeys.length > 1 && (
                  <div className="p-3 bg-indigo-950/40 border border-indigo-500/40 rounded-xl text-indigo-200 text-xs flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <Layers className="w-4 h-4 text-indigo-400 flex-shrink-0" />
                      <span>একসাথে <strong>{detectedBatchKeys.length} টি</strong> কী সনাক্ত হয়েছে ({detectedBatchKeys.map(k => k.provider).join(', ')})</span>
                    </div>
                    <button
                      onClick={handleAddBatchKeys}
                      className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-lg transition-all flex-shrink-0 cursor-pointer shadow-md"
                    >
                      সবগুলো আলাদা করে যুক্ত করুন
                    </button>
                  </div>
                )}
              </div>

              {/* Saved Keys List */}
              <div className="space-y-3">
                <div className="flex items-center justify-between text-slate-400 text-xs">
                  <span>সংরক্ষিত কী সমূহ ({keys.length})</span>
                  <span>{keys.filter(k => k.isActive).length} টি সক্রিয়</span>
                </div>

                {keys.length === 0 ? (
                  <div className="p-8 text-center bg-slate-900/30 border border-slate-800/80 rounded-2xl text-slate-500 italic">
                    কোনো কাস্টম API কী যোগ করা হয়নি। উপরের ফর্মে আপনার Google Gemini (AQ. / AIza) অথবা OpenRouter কী দিয়ে মডেল সিলেক্ট করে যুক্ত করুন।
                  </div>
                ) : (
                  keys.map((item) => {
                    const test = testResults[item.id];
                    const isVisible = showKeys[item.id];
                    const providerModels = PROVIDER_MODELS[item.provider] || [];

                    return (
                      <div
                        key={item.id}
                        className={`p-4 rounded-xl border transition-all ${
                          item.isActive
                            ? 'bg-slate-900/80 border-slate-700/80'
                            : 'bg-slate-950/40 border-slate-800/40 opacity-60'
                        }`}
                      >
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                          <div className="flex items-center gap-2.5 overflow-hidden">
                            <span className="px-2 py-0.5 rounded-md text-[10px] font-bold uppercase bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                              {item.provider}
                            </span>
                            <span className="font-semibold text-white text-xs truncate">
                              {item.name || 'API Key'}
                            </span>
                            
                            {/* Model selector directly on the card */}
                            <select
                              value={item.model || ''}
                              onChange={(e) => handleUpdateKeyModel(item.id, e.target.value)}
                              className="px-2 py-0.5 rounded-md text-[10px] font-mono bg-slate-950 border border-slate-700 text-slate-300 focus:outline-none focus:border-indigo-500 cursor-pointer"
                              title="এই কী-এর জন্য মডেল পরিবর্তন করুন"
                            >
                              {providerModels.map(m => (
                                <option key={m.id} value={m.id}>
                                  ⚡ {m.id}
                                </option>
                              ))}
                              {item.model && !providerModels.some(m => m.id === item.model) && (
                                <option value={item.model}>⚡ {item.model} (Custom)</option>
                              )}
                            </select>
                          </div>

                          <div className="flex items-center gap-2 flex-shrink-0 self-end sm:self-auto">
                            {/* Toggle Active */}
                            <button
                              onClick={() => handleToggleKey(item.id)}
                              className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition-all cursor-pointer ${
                                item.isActive
                                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                                  : 'bg-slate-800 text-slate-400 border border-slate-700'
                              }`}
                            >
                              {item.isActive ? 'সক্রিয়' : 'নিষ্ক্রিয়'}
                            </button>

                            {/* Test Key */}
                            <button
                              onClick={() => handleTestKey(item)}
                              disabled={isTesting === item.id}
                              className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-[10px] font-semibold border border-slate-700 transition-all flex items-center gap-1 cursor-pointer"
                              title="টেস্ট কানেক্টিভিটি"
                            >
                              {isTesting === item.id ? (
                                <RefreshCw className="w-3 h-3 animate-spin text-indigo-400" />
                              ) : (
                                <Zap className="w-3 h-3 text-amber-400" />
                              )}
                              <span>টেস্ট</span>
                            </button>

                            {/* Delete */}
                            <button
                              onClick={() => handleDeleteKey(item.id)}
                              className="p-1 hover:text-red-400 text-slate-500 rounded transition-colors cursor-pointer"
                              title="মুছে ফেলুন"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                        {/* Key snippet */}
                        <div className="mt-2 flex items-center gap-2 text-[11px] font-mono text-slate-400">
                          <span>
                            {isVisible
                              ? item.apiKey
                              : `${item.apiKey.slice(0, 8)}••••••••${item.apiKey.slice(-4)}`}
                          </span>
                          <button
                            onClick={() => setShowKeys(prev => ({ ...prev, [item.id]: !prev[item.id] }))}
                            className="text-slate-500 hover:text-slate-300 transition-colors cursor-pointer"
                          >
                            {isVisible ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                          </button>
                        </div>

                        {/* Test Result Feedback */}
                        {test && (
                          <div
                            className={`mt-2 p-2 rounded-lg text-[11px] flex items-center gap-1.5 ${
                              test.success
                                ? 'bg-emerald-950/40 border border-emerald-500/30 text-emerald-300'
                                : 'bg-rose-950/40 border border-rose-500/30 text-rose-300'
                            }`}
                          >
                            {test.success ? <Check className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" /> : <AlertCircle className="w-3.5 h-3.5 text-rose-400 flex-shrink-0" />}
                            <span className="truncate">{test.message || (test.success ? `সফলভাবে কানেক্ট হয়েছে (${test.latencyMs}ms)` : 'কানেক্ট হতে পারেনি')}</span>
                          </div>
                        )}
                      </div>
                    );
                  })
                )}
              </div>
            </div>

            {/* Footer */}
            <div className="px-6 py-4 border-t border-slate-800/80 bg-slate-900/40 flex justify-end">
              <button
                onClick={onClose}
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-xl transition-all cursor-pointer shadow-lg shadow-indigo-600/30 text-xs"
              >
                সংরক্ষণ ও বন্ধ করুন
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
