import React, { useState, useEffect } from 'react';
import { X, Settings, Key, Github, Flame, Shield, Cpu, Sliders, Check } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { getSettings, saveSettings } from '../lib/secretsManager';
import { SettingsConfig } from '../types/secrets';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenSecrets: () => void;
  onOpenGitHub: () => void;
  onOpenFirebase: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  onOpenSecrets,
  onOpenGitHub,
  onOpenFirebase,
}) => {
  const [settings, setSettingsState] = useState<SettingsConfig>(getSettings());
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setSettingsState(getSettings());
      setSaved(false);
    }
  }, [isOpen]);

  const handleUpdate = (updates: Partial<SettingsConfig>) => {
    const next = { ...settings, ...updates };
    setSettingsState(next);
    saveSettings(next);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm"
          />

          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 15 }}
            className="relative w-full max-w-lg bg-[#0c1017] border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col z-10"
          >
            {/* Header */}
            <div className="px-6 py-4 border-b border-slate-800/80 flex items-center justify-between bg-slate-900/50">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-indigo-500/10 border border-indigo-500/20 rounded-xl text-indigo-400">
                  <Settings className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">সেটিংস ও কনফিগারেশন</h3>
                  <p className="text-xs text-slate-400">মডেল প্রেফারেন্স ও কানেকশন সেটিংস</p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Body */}
            <div className="p-6 space-y-4 text-xs overflow-y-auto">
              {/* Quick links */}
              <div className="grid grid-cols-3 gap-2 pb-2">
                <button
                  onClick={() => {
                    onClose();
                    onOpenSecrets();
                  }}
                  className="flex flex-col items-center gap-1.5 p-3 rounded-xl bg-slate-900 border border-slate-800 hover:border-indigo-500/50 hover:bg-slate-800/60 transition-all text-slate-300 cursor-pointer"
                >
                  <Key className="w-4 h-4 text-indigo-400" />
                  <span className="font-semibold text-[11px]">API Keys</span>
                </button>
                <button
                  onClick={() => {
                    onClose();
                    onOpenGitHub();
                  }}
                  className="flex flex-col items-center gap-1.5 p-3 rounded-xl bg-slate-900 border border-slate-800 hover:border-indigo-500/50 hover:bg-slate-800/60 transition-all text-slate-300 cursor-pointer"
                >
                  <Github className="w-4 h-4 text-slate-300" />
                  <span className="font-semibold text-[11px]">GitHub</span>
                </button>
                <button
                  onClick={() => {
                    onClose();
                    onOpenFirebase();
                  }}
                  className="flex flex-col items-center gap-1.5 p-3 rounded-xl bg-slate-900 border border-slate-800 hover:border-amber-500/50 hover:bg-slate-800/60 transition-all text-slate-300 cursor-pointer"
                >
                  <Flame className="w-4 h-4 text-amber-400" />
                  <span className="font-semibold text-[11px]">Firebase</span>
                </button>
              </div>

              {/* Provider preference */}
              <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-xl space-y-2">
                <div className="flex items-center gap-2 font-semibold text-slate-200">
                  <Cpu className="w-4 h-4 text-indigo-400" />
                  <span>পছন্দের প্রোভাইডার (Preferred Provider)</span>
                </div>
                <select
                  value={settings.preferredProvider || 'all'}
                  onChange={(e) => handleUpdate({ preferredProvider: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none focus:border-indigo-500"
                >
                  <option value="all">সব সক্রিয় প্রোভাইডার (অটো-ব্যালেন্সিং)</option>
                  <option value="gemini">Google Gemini (AI Studio)</option>
                  <option value="openrouter">OpenRouter API</option>
                  <option value="grok">xAI Grok</option>
                </select>
              </div>

              {/* Auto Failover */}
              <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-xl flex items-center justify-between">
                <div>
                  <div className="font-semibold text-slate-200">অটো-ফেইলওভার (Auto-Failover)</div>
                  <div className="text-[11px] text-slate-400">রেট লিমিট বা এরর হলে স্বয়ংক্রিয়ভাবে পরবর্তী কী-তে সুইচ করবে</div>
                </div>
                <input
                  type="checkbox"
                  checked={settings.autoFailover}
                  onChange={(e) => handleUpdate({ autoFailover: e.target.checked })}
                  className="w-4 h-4 text-indigo-600 rounded bg-slate-950 border-slate-700"
                />
              </div>

              {/* Safe pacing */}
              <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-xl flex items-center justify-between">
                <div>
                  <div className="font-semibold text-slate-200">সেফ পেসিং (Safe Pacing)</div>
                  <div className="text-[11px] text-slate-400">অনাকাঙ্ক্ষিত রেট লিমিট এড়াতে রিকোয়েস্ট রেট নিয়ন্ত্রণ করবে</div>
                </div>
                <input
                  type="checkbox"
                  checked={settings.safePacing}
                  onChange={(e) => handleUpdate({ safePacing: e.target.checked })}
                  className="w-4 h-4 text-indigo-600 rounded bg-slate-950 border-slate-700"
                />
              </div>

              {saved && (
                <div className="p-2.5 bg-emerald-950/40 border border-emerald-500/30 rounded-xl text-emerald-300 text-xs flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>সেটিংস স্বয়ংক্রিয়ভাবে সেভ হয়েছে!</span>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="px-6 py-4 border-t border-slate-800/80 bg-slate-900/40 flex justify-end">
              <button
                onClick={onClose}
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-xl transition-all cursor-pointer shadow-lg shadow-indigo-600/30 text-xs"
              >
                সম্পন্ন
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
