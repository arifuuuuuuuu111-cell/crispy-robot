import React, { useState } from 'react';
import { X, Wrench, Code2, Palette, Globe, Copy, Check, Sparkles, FileText } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface ToolsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ToolsModal: React.FC<ToolsModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'palette' | 'formatter' | 'meta'>('palette');
  const [copied, setCopied] = useState<string | null>(null);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopied(id);
    setTimeout(() => setCopied(null), 2000);
  };

  const colorPalettes = [
    {
      name: "Cyberpunk Indigo",
      colors: ["#020617", "#0f172a", "#6366f1", "#a855f7", "#ec4899", "#38bdf8"]
    },
    {
      name: "Emerald Modern",
      colors: ["#064e3b", "#059669", "#10b981", "#34d399", "#a7f3d0", "#022c22"]
    },
    {
      name: "Sunset Flare",
      colors: ["#450a0a", "#dc2626", "#ea580c", "#f59e0b", "#fde047", "#1c1917"]
    },
    {
      name: "Nord Minimal",
      colors: ["#2e3440", "#3b4252", "#434c5e", "#88c0d0", "#81a1c1", "#5e81ac"]
    }
  ];

  const metaTemplate = `<!-- Primary Meta Tags -->
<title>My Nexus Project</title>
<meta name="title" content="My Nexus Project" />
<meta name="description" content="Generated with Nexus AI Studio" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />

<!-- Open Graph / Facebook -->
<meta property="og:type" content="website" />
<meta property="og:title" content="My Nexus Project" />
<meta property="og:description" content="Generated with Nexus AI Studio" />

<!-- Twitter -->
<meta property="twitter:card" content="summary_large_image" />
<meta property="twitter:title" content="My Nexus Project" />
<meta property="twitter:description" content="Generated with Nexus AI Studio" />`;

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm"
          />

          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 15 }}
            className="relative w-full max-w-2xl bg-[#0c1017] border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh] z-10"
          >
            {/* Header */}
            <div className="px-6 py-4 border-b border-slate-800/80 flex items-center justify-between bg-slate-900/50">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-indigo-500/10 border border-indigo-500/20 rounded-xl text-indigo-400">
                  <Wrench className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">ডেভেলপার টুলকিট (Toolkit)</h3>
                  <p className="text-xs text-slate-400">ওয়েবসাইট তৈরিতে প্রয়োজনীয় সহায়ক টুলস</p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Tabs */}
            <div className="flex border-b border-slate-800 px-6 gap-2 pt-2 bg-slate-950/30">
              <button
                onClick={() => setActiveTab('palette')}
                className={`flex items-center gap-2 px-3 py-2 text-xs font-semibold border-b-2 transition-all ${
                  activeTab === 'palette'
                    ? 'border-indigo-500 text-indigo-400'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <Palette className="w-3.5 h-3.5" />
                কালার প্যালেট
              </button>
              <button
                onClick={() => setActiveTab('meta')}
                className={`flex items-center gap-2 px-3 py-2 text-xs font-semibold border-b-2 transition-all ${
                  activeTab === 'meta'
                    ? 'border-indigo-500 text-indigo-400'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <Globe className="w-3.5 h-3.5" />
                SEO মেটা ট্যাগ
              </button>
            </div>

            {/* Content */}
            <div className="p-6 overflow-y-auto space-y-4">
              {activeTab === 'palette' && (
                <div className="space-y-4">
                  <p className="text-xs text-slate-400">যেকোনো রঙে ক্লিক করে হেক্স কোড কপি করুন:</p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {colorPalettes.map((p, idx) => (
                      <div key={idx} className="p-4 bg-slate-900/60 border border-slate-800 rounded-xl">
                        <div className="text-xs font-bold text-slate-200 mb-2">{p.name}</div>
                        <div className="flex gap-2">
                          {p.colors.map((c, cIdx) => (
                            <button
                              key={cIdx}
                              onClick={() => copyToClipboard(c, `${idx}-${cIdx}`)}
                              className="relative flex-1 h-10 rounded-lg transition-transform hover:scale-105 group border border-white/10"
                              style={{ backgroundColor: c }}
                              title={`Copy ${c}`}
                            >
                              {copied === `${idx}-${cIdx}` && (
                                <span className="absolute inset-0 flex items-center justify-center bg-black/50 text-white rounded-lg">
                                  <Check className="w-3.5 h-3.5" />
                                </span>
                              )}
                            </button>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {activeTab === 'meta' && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-slate-400">আপনার প্রজেক্টের index.html ফাইলে ব্যবহারের জন্য:</span>
                    <button
                      onClick={() => copyToClipboard(metaTemplate, 'meta')}
                      className="flex items-center gap-1.5 px-3 py-1 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-lg transition-all"
                    >
                      {copied === 'meta' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copied === 'meta' ? 'কপি হয়েছে' : 'কোড কপি করুন'}</span>
                    </button>
                  </div>
                  <pre className="p-4 bg-slate-950 border border-slate-800 rounded-xl text-slate-300 font-mono text-xs overflow-x-auto leading-relaxed">
                    {metaTemplate}
                  </pre>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="px-6 py-3 border-t border-slate-800/80 bg-slate-900/40 flex justify-end">
              <button
                onClick={onClose}
                className="px-4 py-1.5 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl transition-all cursor-pointer"
              >
                বন্ধ করুন
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
