export interface ChatMessage {
  role: 'user' | 'model';
  parts: Array<{ text: string }>;
  imageUrl?: string;
  keyInfo?: any;
}

export interface ChatSession {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  messages: ChatMessage[];
  mode?: string;
  generatedHtml?: string;
  previewUrl?: string;
}

const DB_NAME = 'NexusChatDB';
const DB_VERSION = 1;
const STORE_NAME = 'sessions';

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      return reject(new Error('IndexedDB not supported'));
    }
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'id' });
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function getAllSessions(): Promise<ChatSession[]> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const req = store.getAll();
      req.onsuccess = () => {
        const results: ChatSession[] = req.result || [];
        results.sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
        resolve(results);
      };
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    try {
      const raw = localStorage.getItem('nexus_sessions_backup');
      if (raw) return JSON.parse(raw);
    } catch {}
    return [];
  }
}

export async function getSession(id: string): Promise<ChatSession | null> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const req = store.get(id);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    try {
      const raw = localStorage.getItem('nexus_sessions_backup');
      if (raw) {
        const sessions: ChatSession[] = JSON.parse(raw);
        return sessions.find(s => s.id === id) || null;
      }
    } catch {}
    return null;
  }
}

export async function saveSession(session: ChatSession): Promise<void> {
  try {
    const db = await openDB();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const req = store.put(session);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.warn('Falling back to localStorage for saveSession:', err);
  }

  // Backup to localStorage
  try {
    const list = await getAllSessions();
    const idx = list.findIndex(s => s.id === session.id);
    if (idx >= 0) {
      list[idx] = session;
    } else {
      list.unshift(session);
    }
    localStorage.setItem('nexus_sessions_backup', JSON.stringify(list.slice(0, 30)));
  } catch {}
}

export async function deleteSession(id: string): Promise<void> {
  try {
    const db = await openDB();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const req = store.delete(id);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.warn('deleteSession error in IndexedDB:', err);
  }

  try {
    const raw = localStorage.getItem('nexus_sessions_backup');
    if (raw) {
      const list: ChatSession[] = JSON.parse(raw);
      localStorage.setItem('nexus_sessions_backup', JSON.stringify(list.filter(s => s.id !== id)));
    }
  } catch {}
}

export async function clearAllSessions(): Promise<void> {
  try {
    const db = await openDB();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const req = store.clear();
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.warn('clearAllSessions error in IndexedDB:', err);
  }
  localStorage.removeItem('nexus_sessions_backup');
}

export function generateSessionTitle(prompt: string): string {
  if (!prompt) return 'নতুন চ্যাট';
  const clean = prompt.replace(/\s+/g, ' ').trim();
  if (clean.length <= 35) return clean;
  return clean.slice(0, 32) + '...';
}

export function extractHtmlFromChatMessages(messages: any[]): string | null {
  if (!messages || messages.length === 0) return null;

  for (let i = messages.length - 1; i >= 0; i--) {
    const m = messages[i];
    if (m.role === 'model' && m.parts && m.parts.length > 0) {
      const text = m.parts.map((p: any) => p.text || '').join('\n');
      
      // Look for ```html ... ```
      const match = text.match(/```html\s*([\s\S]*?)```/i);
      if (match && match[1]) {
        return match[1].trim();
      }

      // Look for <!DOCTYPE html> ... </html>
      if (text.includes('<!DOCTYPE html>') || text.includes('<html')) {
        const start = text.indexOf('<!DOCTYPE html>') !== -1 ? text.indexOf('<!DOCTYPE html>') : text.indexOf('<html');
        const end = text.lastIndexOf('</html>');
        if (start !== -1 && end !== -1 && end > start) {
          return text.substring(start, end + 7).trim();
        }
      }
    }
  }
  return null;
}
