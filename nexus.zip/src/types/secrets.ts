export type ProviderType = 'gemini' | 'openrouter' | 'grok' | 'all' | string;

export interface ApiKeyItem {
  id: string;
  provider: ProviderType;
  name?: string;
  apiKey: string;
  model?: string;
  isActive?: boolean;
  rpmLimit?: number;
  latencyMs?: number;
  lastUsed?: number;
  status?: 'active' | 'rate_limited' | 'error' | 'testing' | 'healthy' | 'cooldown';
  lastError?: string | null;
}

export interface SettingsConfig {
  autoFailover: boolean;
  safePacing: boolean;
  minRequestIntervalMs: number;
  preferredProvider: string;
  customInstruction?: string;
  temperature?: number;
  maxOutputTokens?: number;
}

export type ActionStepKind = 
  | 'thought' 
  | 'command' 
  | 'read' 
  | 'edit' 
  | 'build' 
  | 'qc' 
  | 'restart' 
  | 'respond' 
  | 'generic';

export interface ActionStep {
  id: string;
  kind: ActionStepKind;
  label: string;
  detail?: string;
  durationSec?: number;
  timestamp: number;
}
